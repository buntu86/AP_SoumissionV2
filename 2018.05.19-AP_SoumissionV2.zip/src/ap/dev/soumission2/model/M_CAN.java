package ap.dev.soumission2.model;

import ap.dev.soumission2.data.Can_Xml;
import ap.dev.soumission2.tools.Log;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "CAN")
public class M_CAN {

    private ObservableList<M_Cahier> listCahiers = FXCollections.observableArrayList();
    
    public M_CAN() {
        Log.msg(0, "ini CAN");
    }

    @XmlElement(name = "Cahiers")
    public ObservableList<M_Cahier> getListCahiers(){
        return this.listCahiers;
    }

    public void update() {
        Log.msg(0, "load CAN");
        Can_Xml.load();
    }
    
    public void save(){
        Log.msg(0, "save CAN");
    }

    @Override
    public String toString() {
        return "M_CAN{" + " listCahiers=" + listCahiers + '}';
    }
}
