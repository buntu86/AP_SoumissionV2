package ap.dev.soumission2.view.dialog;

import ap.dev.soumission2.MainApp;
import ap.dev.soumission2.model.M_Cahier;
import ap.dev.soumission2.tools.Log;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

public class EditCANController implements Initializable{

    private Stage stage;
    
    @FXML
    private TableView<M_Cahier> table;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Log.msg(0, MainApp.getCan().toString());
        
        
    }

    
    public void setStage(Stage editListStage) {
        this.stage = editListStage;
        /*
        //ESC touch listener
        stage.addEventHandler(KeyEvent.KEY_RELEASED, (KeyEvent event) -> {
            if (KeyCode.ESCAPE == event.getCode()) {
                if(table.getSelectionModel().getSelectedItem() != null)
                    table.getSelectionModel().clearSelection();
                else
                    stage.close();
            }
        });*/
    }
}    
    
/*    @FXML
    private TableView<M_Can> table;
    
    @FXML
    private TableColumn<M_Can, Integer> num;
    
    @FXML
    private TableColumn<M_Can, Integer> annee;

    @FXML
    private TableColumn<M_Can, String> titre;

    @FXML
    private TextField tf_num;

    @FXML
    private TextField tf_annee;
    
    @FXML
    private TextField tf_titre;

    @FXML
    private Button btn_ajouter;

    @FXML
    private Button btn_modifier;
    
    private int index = 0;
    M_CanList list = new M_CanList();
    
        
        table.setItems(list.getList());
        num.setCellValueFactory(cellData -> cellData.getValue().numProperty().asObject());
        annee.setCellValueFactory(cellData -> cellData.getValue().anneeProperty().asObject());
        titre.setCellValueFactory(cellData -> cellData.getValue().titreProperty());
        
        btn_modifier.setDisable(true);

        table.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if(newSelection != null)
            {
                Log.msg(0, table.getSelectionModel().getSelectedItem().getNum() + "");
                btn_modifier.setDisable(false);
                btn_ajouter.setDisable(true);
                tf_num.setText(String.valueOf(obs.getValue().getNum()));
                tf_annee.setText(String.valueOf(obs.getValue().getAnnee()));
                tf_titre.setText(obs.getValue().getTitre());
                index = table.getSelectionModel().selectedIndexProperty().get();
            }
            else
            {
                btn_modifier.setDisable(true);
                btn_ajouter.setDisable(false);
                tf_num.clear();
                tf_annee.clear();
                tf_titre.clear();
                index = 0;
            }
        });
    }    
    
    @FXML
    public void update(){
        Log.msg(0, "CanList_XML - 00");
        list.update(index, new M_Can(0, Integer.parseInt(tf_num.getText()), Integer.parseInt(tf_annee.getText()), tf_titre.getText()));
        Log.msg(0, "CanList_XML - 0");
        CanList_Xml.saveListCanToXML(list);
        Log.msg(0, "CanList_XML - 01");
        btn_modifier.setDisable(true);
        btn_ajouter.setDisable(false);
        tf_num.clear();
        tf_annee.clear();
        tf_titre.clear();
        index = 0;
    }
    
    @FXML
    public void add(){
        if(tf_num.getText().trim()!=null)
        {
            M_Can newCahier = new M_Can(0, Integer.parseInt(tf_num.getText()), Integer.parseInt(tf_annee.getText()), tf_titre.getText());
            list.add(newCahier);
            CanList_Xml.saveListCanToXML(list);
            tf_num.clear();
            tf_annee.clear();
            tf_titre.clear();       
        }
    }
    
    @FXML
    public void close(){
        this.stage.close();
    }

    }    
}

*/

